<div class="sidebar-wrapper">
    <ul class="nav">
        <li class="nav-item active ">
            <a class="nav-link" href="./user.php">
                <i class="material-icons">person</i>
                <p>User Profile</p>
            </a>
        </li>
        <li class="nav-item ">
            <a class="nav-link" href="./institution.php">
                <i class="material-icons">person</i>
                <p>Institution Profile</p>
            </a>
        </li>
        <li class="nav-item ">
            <a class="nav-link" href="./feedback.php">
                <i class="material-icons">content_paste</i>
                <p>FeedBack</p>
            </a>
        </li>

        <li class="nav-item ">
            <a class="nav-link" href="./notifications.php">
                <i class="material-icons">notifications</i>
                <p>Notifications</p>
            </a>
        </li>
        <li class="nav-item ">
            <a class="nav-link" href="./rtl.php">
                <i class="material-icons">language</i>
                <p>Support</p>
            </a>
        </li>

    </ul>
</div> 